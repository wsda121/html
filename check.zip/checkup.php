		  
	<html>
<body>

<h1> Price Checkup?</h1>	


<?php
$carType = $_POST['car_type'];
$componontType  = $_POST['componont'];

$categories = array( 
  array ( array( 'CAR_TIR', 'Tires', 100),
          array( 'CAR_OIL', 'Oil', 10),
          array( 'CAR_SPK', 'Spark Plugs', 4)
   ),
  array ( array( 'VAN_TIR', 'Tires', 120),
          array( 'VAN_OIL', 'Oil', 12),
          array( 'VAN_SPK', 'Spark Plugs', 5)
  ),
  array ( array( 'TRUCK_TIR', 'Tires', 150),
          array( 'TRUCK_OIL', 'Oil', 15),
          array( 'TRUCK_SPK', 'Spark Plugs', 6) ));
		
		
		/* --------------------------------------------------------------------------------------------------------------------------------- */
		// Output Tires price for car
		if ($carType == 'car'  && $componontType  == 'tire') {
		echo "Car type: Car"  . "<br>" . "Component: " .$categories[0][0][1] . "<br>"  . "Price: $". $categories[0][0][2];;
		}
		
			// Output Oil price for car
		elseif ($carType == 'car'  && $componontType  == 'oil') {
		echo "Car type: Car"  . "<br>" . "Component: " .$categories[0][1][1] . "<br>"  . "Price: $". $categories[0][1][2];;
		}
		
			// Output Spark pluges price for car
			elseif ($carType == 'car'  && $componontType  == 'sparkPlugs') {
		echo "Car type: Car"  . "<br>" . "Component: " .$categories[0][2][1] . "<br>"  . "Price: $". $categories[0][2][2];;
		}
		
		
		/* --------------------------------------------------------------------------------------------------------------------------------- */
		 // Output Tires price for van
		if ($carType == 'van'  && $componontType  == 'tire') {
		echo "Car type: Van"  . "<br>" . "Component: " .$categories[1][0][1] . "<br>"  . "Price: $". $categories[1][0][2];;
		}
		
		// Output Oil price for van
		elseif ($carType == 'van'  && $componontType  == 'oil') {
		echo "Car type: Van"  . "<br>" . "Component: " .$categories[1][1][1] . "<br>"  . "Price: $". $categories[1][1][2];;
		}
		
			// Output Spark pluges price for van
			elseif ($carType == 'van'  && $componontType  == 'sparkPlugs') {
		echo "Car type: Van"  . "<br>" . "Component: " .$categories[1][2][1] . "<br>"  . "Price: $". $categories[1][2][2];;
		}
		/* --------------------------------------------------------------------------------------------------------------------------------- */
		 // Output Tires price for truck
		if ($carType =='truck' && $componontType == 'tire') {
			echo  "Car type: Truck"  . "<br>" . "Component: " .$categories[2][0][1] . "<br>"  . "Price: $". $categories[2][0][2];;
		}
		
		
		// Output Oil price for truck
		elseif ($carType == 'truck'  && $componontType  == 'oil') {
		echo "Car type: Truck"  . "<br>" . "Component: " .$categories[2][1][1] . "<br>"  . "Price: $". $categories[2][1][2];;
		}
		
		// Output Spark pluges price for truck
			elseif ($carType == 'truck'  && $componontType  == 'sparkPlugs') {
		echo "Car type: Truck"  . "<br>" . "Component: " .$categories[2][2][1] . "<br>"  . "Price: $". $categories[2][2][2];;
		}
		
		
		
			
		
	
		
		
		
		
	/*
		elseif ($componontType == 'Oil')
		
	
		*/
	
		
		
		
		
	
	
		  
?>
	


		  
  
		  

</body>
</html>